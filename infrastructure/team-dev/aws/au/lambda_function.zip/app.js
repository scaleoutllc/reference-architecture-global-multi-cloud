exports.handler = (event, context, callback) => {
    callback(null, 'ap-southeast-1');
}